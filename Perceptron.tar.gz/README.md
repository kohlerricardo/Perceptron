# Perceptron

Classificador utilizando perceptron que gera classes, com base em uma entrada. 
Após isso treina um perceptron para realizar a classificação. 
Exemplos classificados, desenha a fronteira encontrada.
Uso:
python perceptron.py <n_amostras> <escala> <stride> <peso1> <peso2>
